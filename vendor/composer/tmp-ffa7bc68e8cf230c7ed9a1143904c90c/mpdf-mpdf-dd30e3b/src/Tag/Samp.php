<?php

namespace Mpdf\Tag;

class Samp extends InlineTag
{


}
