<?php

namespace Mpdf\Tag;

class Del extends InlineTag
{


}
